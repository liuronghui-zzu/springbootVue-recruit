const base = {
    get() {
                return {
                url : "http://localhost:8080/springbootjlvpC/",
                name: "springbootjlvpC"
            }
            },
    getProjectName(){
        return {
            projectName: "校园招聘系统"
        } 
    }
}
export default base